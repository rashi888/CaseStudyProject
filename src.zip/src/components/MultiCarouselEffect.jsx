import React from 'react'

const MultiCarouselEffect = () => {
  return (
    <div>MultiCarouselEffect</div>
  )
}

export default MultiCarouselEffect