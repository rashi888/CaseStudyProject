import React from 'react'

function More() {
    return (
        <div>More</div>
    )
}

export default More